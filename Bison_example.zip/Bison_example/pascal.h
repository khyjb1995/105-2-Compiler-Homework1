extern int yylex();
extern int yyparse();
extern FILE *yyin;
extern FILE *yyout;
extern FILE *yyerr;

extern char pas_name[16];
extern int pas_val;

extern int yyerror( char* );

